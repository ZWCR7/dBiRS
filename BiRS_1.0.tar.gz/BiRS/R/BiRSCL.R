#' The \code{SigDetCL}: function for CL binary search based signal detection control FWER without dimension reduction, only for two sample
#' @param X: sample matrix
#' @param Y: sample matrix for second population, alternatively
#' @param foldlen: The length be splitted, default 4096, if dimension of X or Y less than 4096, suggest the dimension of X
#' @param trunc: The truncation parameter for the smallest signal region
#' @param MB: multiplier bootstrap size, default 1000
#' @param alpha: the size of test, default 0.05
#' @param ReMax: the maximum number for re-searching
#' @param COMPU: whether compute the p-value and DCF statistics for signal regions
#' @return \code{BSCL_res}: the detection results, which include the specific signal region and the corresponding statistics and p-value
#' @return \code{index}: the number of research procedure

SigDetCL = function(X, Y, foldlen = 4096, trunc = 3, alpha = 0.05, ReMax = 10, COMPU = F)
{
  p = ncol(X)
  Signal = rep(0, p)
  split = ceiling(p/foldlen)
  
  S.split = list()
  
  if (split == 1)
  {
    S.split = c(S.split, list(1:p))
  }
  if (split != 1)
  {
    for (i in 1:(split - 1))
    {
      S.split = c(S.split, list(((i-1)*foldlen+1):(i*foldlen)))
    }
    S.split = c(S.split, list(((split-1)*foldlen+1):p))
  }
  
  
  totalre = CLTest(X, Y, alpha)
  
  UnVec = totalre$MIMat
  bmax_prm = totalre$bound
  
  rm(totalre)
  
  Unprm = rep(0, split)
  for (sp in 1:split)
  {
    Unprm[sp] = max(UnVec[S.split[[sp]]])
  }
  
  reject_ind = rep(0, split)
  Slist = list()
  for (sp in 1:split)
  {
    if (Unprm[sp] > bmax_prm) 
    {
      reject_ind[sp] = 1
      ps = length(S.split[[sp]]); ms = ceiling(ps/2)
      Slist = c(Slist, list(S.split[[sp]][1:ms]))
      Slist = c(Slist, list(S.split[[sp]][(ms + 1):ps]))
    }
  }
  
  if (sum(reject_ind) == 0) return("there is no evidence that there exist signal region")
  
  Signal = BiSearchCL(UnVec, Slist, Signal, trunc, alpha)
  
  ind = which(Signal == 1)
  UnVec[ind] = 0
  loop.p = p - length(ind)
  loop.bound = -log(pi*log(1/(1 - alpha))^2) + 2*log(loop.p) - log(log(loop.p))
  loop.ind = (max(UnVec) > loop.bound)
  
  index = 0
  while ((loop.ind == T) & (index <= ReMax))
  {
    Unprm.loop = rep(0, split)
    for (sp in 1:split)
    {
      Unprm.loop[sp] = max(UnVec[S.split[[sp]]])
    }
    
    Slist.loop = list()
    for (sp in 1:split)
    {
      if (Unprm.loop[sp] > loop.bound) 
      {
        p.loop = length(S.split[[sp]]); m.loop = ceiling(p.loop/2)
        Slist.loop = c(Slist.loop, list(S.split[[sp]][1:m.loop]))
        Slist.loop = c(Slist.loop, list(S.split[[sp]][(m.loop + 1):p.loop]))
      }
    }
    
    Signal = BiSearchCL(UnVec, Slist.loop, Signal, trunc, alpha)
    
    ind = which(Signal == 1)
    UnVec[ind] = 0
    loop.p = p - length(ind)
    loop.bound = -log(pi*log(1/(1 - alpha))^2) + 2*log(loop.p) - log(log(loop.p))
    loop.ind = (max(UnVec) > loop.bound)
    
    index = index + 1
  }
  
  indF = which(Signal == 1)
  nF = length(indF)
  startind = indF[1]; endind = NULL
  for (i in 1:(nF - 1))
  {
    if ((indF[i + 1] - indF[i]) > 1)
    {
      endind = c(endind, indF[i])
      startind = c(startind, indF[i + 1])
    }
  }
  endind = c(endind, indF[nF])
  
  Stat = rep(0, length(startind))
  Pv = rep(1, length(startind))
  
  if (COMPU)
  {
    for (j in 1:length(startind))
    {
      resj = CLTest(as.matrix(X[, startind[j]:endind[j]]), as.matrix(Y[, startind[j]:endind[j]]), alpha)
      Stat[j] = resj$MI
      Pv[j] = resj$Pvalue
    }
  }
  
  BSCL_res = data.frame(startind, endind, Stat, Pv)
  return(list(BSCL_res = BSCL_res, index = index))
}