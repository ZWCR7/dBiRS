#' The \code{Pv.boot}: function for computing empirical P-value when bootstrap method been used
#' @param T0: the realization of test statistic
#' @param x: booted quantile sequence
#' @return \code{p.grid}: The P-value
Pv.boot = function(T0, x)
{
  MB = length(x)
  p.grid = seq(0, 1, 1/MB)
  qx = quantile(x, p.grid)
  p.grid[which.min((T0 - qx)^2)]
}
###############################################################################################