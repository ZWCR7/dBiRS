#' The \code{SigScanDCF}: function for scan test obtain with a DCF Test
#' @param X: sample matrix
#' @param Y: sample matrix for second population, alternatively
#' @param foldlen: The length be splitted, default 4096, if dimension of X or Y less than 4096, suggest the dimension of X
#' @param Lmin: The smallest length of signal regions, default 40
#' @param Lmax: The largest length of signal regions, default 200
#' @param skip: The skip of different length of signal regions, default 1
#' @param MB: multiplier bootstrap size, default 1000
#' @param alpha: the size of test, default 0.05
#' @param COMPU: the type for computing p value, c('None', 'Region', 'Point'), default 'None' for not computing; 'Region' for computing
#' region based p value and 'Point' for point based p value.
#' @param Pvm: the type of p value, c('Emp', 'Asy'), default 'Emp' for empirical p value, alternative 'Asy' for asymptotic p value 
#' (only for point based p value)
#' @return \code{BSDCF_res}: the detection results, which include the specific signal region and the corresponding statistics and p-value 
SigScanDCF = function(X, Y = NULL, Lmin = 40, Lmax = 200, skip = 1, MB = 1000, alpha = 0.05)
{
  p = ncol(X)
  intervals = bounded.intervals(p, Lmin, Lmax, skip)
  
  DCFStat = XFTest(X, Y, MB, alpha)
  Un = DCFStat$UnVec; thresh = DCFStat$bound
  
  SelectStat = rep(0, nrow(intervals))
  
  for (i in 1:nrow(intervals))
  {
    Uni = Un[intervals[i, 1]:intervals[i, 2]]
    SelectStat[i] = max(Uni)
  }
  
  index_stop = 1
  startind = c(); endind = c()
  while(index_stop > 0)
  {
    #print(paste0('Greedy Segmentation Step:', greedy_num))
    
    maxstat = max(SelectStat)
    
    if (maxstat < thresh) break;
    
    index_max = which(SelectStat == maxstat)
    #stat = SelectStat[index_max]
    
    st = intervals[index_max, 1]; et = intervals[index_max, 2]
    
    Belong_Func = function(x) return((x[1] > intervals[index_max, 2]) + (x[2] < intervals[index_max, 1]))
    Belong_index = apply(intervals, 1, Belong_Func)
    
    index_out = which(Belong_index == 1)
    intervals = as.matrix(intervals[index_out, ])
    
    SelectStat = SelectStat[index_out]
    #beta_diff = beta_diff[-index_belong]
    
    startind = c(startind, st); endind = c(endind, et)
    index_stop = length(intervals)
  }
  
  SDDCF_Res = data.frame(startind, endind)
  
  return(list(SDDCF_Res = SDDCF_Res))
}


bounded.intervals = function(n, Lmin, Lmax, skip)
{
  n	= as.integer(n)
  
  lvector = unique(c(seq(Lmin, Lmax, by = skip), Lmax))
  
  start = c(); end = c()
  for (l in lvector)
  {
    startl = 1:(n - l + 1)
    endl = l:n
    
    start = c(start, startl); end = c(end, endl)
  }
  
  boundary_mtx = cbind(start, end)
  
  return(boundary_mtx)
}
