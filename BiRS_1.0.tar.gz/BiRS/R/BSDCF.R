#' The \code{BiSearchDCF}: function for binary search for signal region
#' @param UnVec: Vector of DCF statistics
#' @param SneX: Matrix of thresholds
#' @param Slist: alternative signal regions for binary search
#' @param trunc: The truncation parameter for the smallest signal region
#' @param MB: multiplier bootstrap size, default 1000
#' @param alpha: the size of test, default 0.05
#' @return \code{Signal}: the p-vector indicates the signal region

BiSearchDCF = function(UnVec, SneX, Slist, Signal, trunc = 3, MB = 1000, alpha = 0.05)
{
  while(length(Slist) != 0)
  {
    Slist1 = list()
    l = length(Slist)
    
    RG = NULL
    UnV = rep(0, l)
    for (i in 1:l)
    {
      UnV[i] = max(UnVec[Slist[[i]]])
      RG = c(RG, Slist[[i]])
    }
    
    bmax = quantile(apply(SneX[, RG], 1, max), prob = 1 - alpha)
    
    for (i in 1:l)
    {
      pi = length(Slist[[i]]); mi = ceiling(pi/2)
      initi = (UnV[i] > bmax)
      
      if (initi == 1 && pi > 2^trunc)
      {
        Slist1 = c(Slist1, list(Slist[[i]][1:mi]))
        Slist1 = c(Slist1, list(Slist[[i]][(mi + 1):pi]))
      }
      
      if (initi == 1 && pi <= 2^trunc)
      {
        index = Slist[[i]]
        Signal[index] = 1
      }
    }
    
    Slist = Slist1
  }
  
  return(Signal)
}