DCFM = function(CaseData, ControlData, MB)
{
  n = nrow(CaseData); m = nrow(ControlData)
  
  MEAN_NA = function(x)
  {
    return(mean(x, na.rm = T))
  }
  
  # VAR_NA = function(x)
  # {
  #   return(var(x, na.rm = T))
  # }
  
  CompuNAnum =  function(x)
  {
    return(sum(is.na(x)))
  }
  
  NAnumCase = apply(CaseData, 2, CompuNAnum)
  NAnumControl = apply(ControlData, 2, CompuNAnum)
  
  nc = n - NAnumCase; mc = m - NAnumControl
  
  MeanCase = apply(CaseData, 2, MEAN_NA)
  MeanControl = apply(ControlData, 2, MEAN_NA)
  
  # VarCase = apply(CaseData, 2, VAR_NA)
  # VarControl = apply(ControlData, 2, VAR_NA)
  
  UnVI = abs(sqrt(nc)*(MeanCase - MeanControl))
  
  for (j in 1:ncol(CaseData))
  {
    CaseData[, j][which(is.na(CaseData[, j]))] = MeanCase[j]
    ControlData[, j][which(is.na(ControlData[, j]))] = MeanControl[j]
  }
  
  res = GMBoot(CaseData, ControlData, t(as.matrix(MeanCase)), t(as.matrix(MeanControl)), MB)
  
  SneXI = matrix(rep(sqrt(nc), MB), MB, length(nc), byrow = T)*abs(res$SneX/matrix(rep(nc, MB), MB, length(nc), byrow = T) - 
                                                                     res$SneY/matrix(rep(mc, MB), MB, length(mc), byrow = T))
  gc()
  
  return(list(SneXI = SneXI, UnVI = UnVI))
}