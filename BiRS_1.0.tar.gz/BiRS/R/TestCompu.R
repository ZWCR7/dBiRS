#' The \code{Rejec}: function for generating test results in DCF test
#' @param UnV: the vector of normalized sum
#' @param SneX: the matrix of booted normalized sum 
#' @param alpha: the size of test, default 0.05
#' @return \code{Un}: the test statistic
#' @return \code{bd}: the threshold under significant level alpha
#' @return \code{rej}: whether the test reject the null hypothesis
Rejec = function(UnV, SneX, alpha = 0.05)
{
  bd = quantile(apply(SneX, 1, max), prob = 1 - alpha)
  Un = max(UnV)
  rej = (Un > bd)
  
  return(list(Un = Un, bd = bd, rej = rej))
}
################################################################################