#' The \code{XFTest}: High-dimensional distribution and correlation-free Test
#' @param X: sample matrix
#' @param Y: sample matrix, default NULL for one sample test
#' @param MB: the size of multiplier bootstrap, default 1000
#' @param alpha: the size of test, default 0.05
#' @return \code{Un}: the value of test statistics
#' @return \code{bound}: the booted threshold
#' @return \code{reject}: whether the test reject the null hypothese
#' @return \code{Pvalue}: the p-value for the test
#' @return \code{UnVec}: the vector of normalized sum
#' @return \code{SneX}: the matrix of booted normalized sum 
XFTest = function(X, Y = NULL, MB = 1000, alpha = 0.05)
{ 
  if (is.null(Y)) 
  {
    re = OneSamTest(X, MB) 
  }
  else
  {
    re = TwoSamTest(X, Y, MB)
  }
  
  UnV = as.vector(re$UnV)
  SneX = re$SneX
  
  Un = max(UnV)
  SneX.max = apply(SneX, 1, max)
  
  bound = quantile(SneX.max, prob = 1 - alpha)
  reject = (Un > bound)
  Pvalue = 1 - Pv.boot(Un, SneX.max)
  
  return(list(Un = Un, bound = bound, reject = reject, Pvalue = Pvalue, UnVec = UnV, SneX = SneX))
}
#####################################################################################################