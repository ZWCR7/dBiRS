// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List GMBoot(arma::mat X, arma::mat Y, arma::mat Xbar, arma::mat Ybar, const int MB)
{
  int n = X.n_rows;
  int m = Y.n_rows;
  int p = X.n_cols;
  
  arma::mat interX;
  arma::mat interY;
  interX.ones(n,1);
  interY.ones(m,1);
  
  arma::mat SneX;
  arma::mat SneY;
  SneX.zeros(MB,p);
  SneY.zeros(MB,p);
  
  // arma::mat ee;
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(413);
  
  SneX = arma::randn<arma::mat>(MB,n)*(X - interX*Xbar);
  SneY = arma::randn<arma::mat>(MB,m)*(Y - interY*Ybar);
  
  return List::create(Named("SneX") = SneX, Named("SneY") = SneY);
}
