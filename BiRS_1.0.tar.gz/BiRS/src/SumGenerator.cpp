// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List SummaryGenerator(arma::mat G, arma::vec phenotype, arma::mat X, arma::vec mu0, arma::vec working, double sigma, int fam, const int MB)
{
  int p = G.n_cols;
  // sample size
  int n = G.n_rows;
  // covariates number
  int q = X.n_cols;
  
  arma::mat UnV = trans(G)*(phenotype - mu0);
  
  // pesudo-residual
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(413);
  arma::mat y;
  
  y = arma::randn<arma::mat>(MB,n);
  
  arma::mat x;
  x.zeros(MB,p);
  
  arma::mat tX_G;
  tX_G.zeros(q,p);
  
  if(fam == 0)
  {
    tX_G = trans(X)*G;
    x = (y*G - y*X*inv(trans(X)*X)*tX_G)*sigma;
  }else
  {
    tX_G = trans(X)*(arma::diagmat(working))*G;
    y = y*arma::diagmat(sqrt(working));
    x = (y*G - y*X*inv(trans(X)*arma::diagmat(working)*X)*tX_G)*sigma;
  }
  
  return List::create(Named("SneX") = x, Named("UnV") = UnV);
}
