// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List SummaryGeneratorGLMM(arma::sp_mat G, arma::vec phenotype, arma::vec mu0, arma::mat XV, arma::mat XXVX_inv, arma::sp_mat Lproj, const int MB)
{
  int p = G.n_cols;
  // sample size
  int n = G.n_rows;
  
  arma::mat Gtilde = G - XXVX_inv*XV*G;
  arma::mat UnV = trans(Gtilde)*(phenotype - mu0);
  
  // pesudo-residual
  arma::mat ee;
  ee = arma::randn<arma::mat>(n,MB);
  
  // pesudo-score
  arma::mat ThresMat;
  ThresMat.zeros(p,MB);
  
  ThresMat = trans(Gtilde)*Lproj*ee;
  
  return List::create(Named("ThresMat") = ThresMat, Named("UnV") = UnV);
}
